<div id="back-borang">
    <a href="<?=base_url('laporan')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a>
</div>
<section>

    <br/>

    
	<div id="table-wrapper">
  		<div id="table-scroll">	
			<table align="center" class="data-table">
                <tr>
                    <th class='col-xs-1'><center>BIL.</center></th> 
                    <th class='col-xs-2'><center>KOD KURSUS</center></th> 
                    <th class='col-xs-8'><center>NAMA KURSUS</center></th> 
                    <th class='col-xs-8'><center>NAMA</center></th> 
                    <th class='col-xs-8'><center>NO PEKERJA</center></th> 
                    <th class='col-xs-8'><center>KAMPUS</center></th> 
                    <th class='col-xs-8'><center>Pusat Pengajian</center></th> 
                    <th class='col-xs-8'><center>Tempoh</center></th>
                </tr>
			<?php
					echo "<br><p><b><font size = '5'>  &nbsp Laporan RP dibawah pusat pengajian</font></b></p>";
                    $no=1;
                    foreach ($result as $row)
					{
						echo "
                            <tr>
								<td><center>".$no.".</center></td>
								<td><center>".$row["KodKursus"]."</center></td>
                                <td><center>".$row["NamaKursus"]."</center></td>
								<td>".$row["NamaStaf"]."</td>
                                <td><center>".$row["NoPekerja"]."</center></td>
                                <td><center>".$row["NamaKampus"]."</center></td>
                                <td><center>".$row["NamaJabBhg"]."</center></td>
								<td>".date('d/m/Y', strtotime($row["TarikhMula"]))."<br> - <br>".date('d/m/Y', strtotime($row["TarikhTamat"]))."</td>
							</tr>";
                        $no++;

					}

			?>

			</table>
		</div>
	</div>

</section>