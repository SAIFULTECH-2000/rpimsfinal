<div id="back-">
    <a href="<?=base_url('laporan')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a>
</div>
<section>
      <center>
        <form method='POST' class="cari">
            <div class="row col-lg-3">
                <div class="col col-lg-2">
                </div>
                <div class="input-group col col-lg-6" style="padding:0;">
                  <span class="input-group-addon"style="padding:0;">
                  <?php
                   
                   $result2 = $this->db->query("SELECT KodJab, NamaJabBhg from jabatan WHERE status='active' ORDER BY NamaJabBhg ASC")->result_array();
                   
                   echo "<select width='100%' name='KodJab' value='KodJab' class='form-control' style='border:0; background-color:#e9ecef;' required>";
                   echo '<option value="" disabled selected hidden>&nbsp&nbsp--</option>';

                  foreach ($result2 as $row) 
                   {
                       echo '<option value="'.$row['KodJab'].'">'.$row['NamaJabBhg'].' &nbsp;('.$row['KodJab'].')</option>';
                   }

                   echo "</select>";
               ?>
                    
                  </span>
                </div>
                <div class="col col-lg-1">
                    <button type='submit' class='button1 button4 button2' name='submit'>CARI</button>
                </div>
                <div class="col col-lg-2">
                </div>
            </div>
            <!--input type='text' placeholder='ISIKAN PENSYARAH UNTUK DICARI' name='search' value="<?php echo $input;?>" style="text-transform:uppercase;"/>
            <button type='submit' class='button1 button4 button2' name='submit'>CARI</button-->
        </form>
    </center>
    <br/>

    
	<div id="table-wrapper">
  		<div id="table-scroll">	
			<table align="center" class="data-table">
                <tr>
                    <th class='col-xs-1'><center>BIL.</center></th> 
                    <th class='col-xs-2'><center>KOD KURSUS</center></th> 
                    <th class='col-xs-8'><center>NAMA KURSUS</center></th> 
                    <th class='col-xs-8'><center>NAMA</center></th> 
                    <th class='col-xs-8'><center>NO PEKERJA</center></th> 
                    <th class='col-xs-8'><center>KAMPUS</center></th> 
                    <th class='col-xs-8'><center>Pusat Pengajian</center></th> 
                    <th class='col-xs-8'><center>Tempoh</center></th>
                </tr>
			<?php
                    if($result!=""){
					echo "<br><p><b><font size = '5'>  &nbsp Laporan RP dibawah pusat pengajian</font></b></p>";
                    $no=1;
                    foreach ($result as $row)
					{
						echo "
                            <tr>
								<td><center>".$no.".</center></td>
								<td><center>".$row["KodKursus"]."</center></td>
                                <td><center>".$row["NamaKursus"]."</center></td>
								<td>".$row["NamaStaf"]."</td>
                                <td><center>".$row["NoPekerja"]."</center></td>
                                <td><center>".$row["NamaKampus"]."</center></td>
                                <td><center>".$row["NamaJabBhg"]."</center></td>
								<td>".date('d/m/Y', strtotime($row["TarikhMula"]))."<br> - <br>".date('d/m/Y', strtotime($row["TarikhTamat"]))."</td>
							</tr>";
                        $no++;

					}
                }else{
                    echo "<td colspan='8'>Tiada</td>";
                }

			?>

			</table>
		</div>
	</div>

</section>