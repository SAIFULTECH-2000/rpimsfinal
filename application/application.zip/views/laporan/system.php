<div id="back-senarai-no-carian">
    <a href="<?=base_url('laporan')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a>
</div>
<section>
    <br/>
	<div id="table-wrapper">
  		<div id="table-scroll">	
			<table align="center" class="data-table">
                <tr>
                    <th class='col-xs-8' rowspan="2"><center>Sistem</center></th> 
                    <th class='col-xs-2' colspan="2"><center>Bilangan</center></th>
                </tr>
                <tr>
                    <th class='col-xs-2'><center>Masih Aktif</center></th> 
                    <th class='col-xs-2'><center>Tidak Aktif</center></th> 
                </tr>
                <?php
					echo "<br><p><b><font size = '5'> <i class='fa fa-archive' aria-hidden='true'></i> &nbsp LAPORAN SISTEM TERBARU</font></b></p>";


					$row = $this->db->query("SELECT COUNT(NoPekerja) AS BilanganStaf FROM staf WHERE status='active'")->row_array();
					$row1 =$this->db->query("SELECT COUNT(NoPekerja) AS BilanganStafTA FROM staf WHERE status='inactive'")->row_array();

					echo "
                        <tr>
                            <td><center>Pensyarah</td>
                            <td><center><b>".$row["BilanganStaf"]."</b></td>
                            <td><center><b>".$row1["BilanganStafTA"]."</b></td>
                        </tr>";

					$row = $this->db->query("SELECT COUNT(KodJab) AS BilanganJabatan FROM jabatan WHERE status='active'")->row_array();
					$row1 = $this->db->query("SELECT COUNT(KodJab) AS BilanganJabatanTA FROM jabatan WHERE status='inactive'")->row_array();

					echo "
                        <tr>
                            <td><center>Jabatan</td>
                            <td><center><b>".$row["BilanganJabatan"]."</b></td>
                            <td><center><b>".$row1["BilanganJabatanTA"]."</b></td>
                        </tr>";

					$row = $this->db->query("SELECT COUNT(KodKampus) AS BilanganKampus FROM kampus WHERE status='active'")->row_array();
					$row1 = $this->db->query("SELECT COUNT(KodKampus) AS BilanganKampusTA FROM kampus WHERE status='inactive'")->row_array();

					echo "
                        <tr>
                            <td><center>Kampus</td>
                            <td><center><b>".$row["BilanganKampus"]."</b></td>
                            <td><center><b>".$row1["BilanganKampusTA"]."</b></td>
                        </tr>";



					$row = $this->db->query("SELECT COUNT(KodKursus) AS BilanganKursus FROM kursus WHERE status='active'")->row_array();
					$row1 = $this->db->query("SELECT COUNT(KodKursus) AS BilanganKursusTA FROM kursus WHERE status='inactive'")->row_array();

					echo "
                        <tr>
                            <td><center>Kursus</td>
                            <td><center><b>".$row["BilanganKursus"]."</b></td>
                            <td><center><b>".$row1["BilanganKursusTA"]."</b></td>
                        </tr>";


					$row = $this->db->query("SELECT COUNT(*) AS BilanganCawangan FROM cawangan WHERE status='active'")->row_array();
					$row1 =$this->db->query("SELECT COUNT(*) AS BilanganCawanganTA FROM cawangan WHERE status='inactive'")->row_array();

					echo "
                        <tr>
                            <td><center>Cawangan</td>
                            <td><center><b>".$row["BilanganCawangan"]."</b></td>
                            <td><center><b>".$row1["BilanganCawanganTA"]."</b></td>
                        </tr>";

					$row = $this->db->query("SELECT COUNT(KodProgram) AS BilanganProgram FROM program WHERE status='active'")->row_array();
					$row1 = $this->db->query("SELECT COUNT(KodProgram) AS BilanganProgramTA FROM program WHERE status='inactive'")->row_array();

					echo "
                        <tr>
                            <td><center>Program</td>
                            <td><center><b>".$row["BilanganProgram"]."</b></td>
                            <td><center><b>".$row1["BilanganProgramTA"]."</b></td>
                        </tr>";


					$row =$this->db->query("SELECT COUNT(*) AS BilanganSubjek FROM subjek WHERE status='active'")->row_array();
					$row1 =$this->db->query("SELECT COUNT(*) AS BilanganSubjekTA FROM subjek WHERE status='inactive'")->row_array();

					echo "
                        <tr>
                            <td><center>Subjek</td>
                            <td><center><b>".$row["BilanganSubjek"]."</b></td>
                            <td><center><b>".$row1["BilanganSubjekTA"]."</b></td>
                        </tr>";

                ?>
            </table>
		</div>
	</div>

</section>