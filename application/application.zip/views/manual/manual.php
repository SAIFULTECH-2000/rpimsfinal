<div id="back-menu">
		<a href="<?=base_url('auth')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a><br><br><br>
</div>

<section>
        <table align="center" width="90%">
        
            <tr>
                <td colspan="5">
                    <b><font size = "5"> <br> <i class="fa fa-fire" aria-hidden="true"></i>&nbsp JENIS MANUAL</font></b> 
                    
                    <hr>
            </tr>
            <tr>
                <td width="20%">
                    <a target='_blank' href="<?=base_url('assets/manual/')?>usermanual.pdf"><div class="container"><br><br><b><center><font size = "5"> <i class="fa fa-file-text-o fa-2x" aria-hidden="true"></i> </font><br><br>MANUAL <br>BERGAMBAR</font></b></div></center></a>
                </td>
                <td width="20%">
                    <a target='_blank' href="<?=base_url('assets/manual/')?>usermanual2.pdf"><div class="container"><br><br><b><center><font size = "5"> <i class="fa fa-file-o fa-2x" aria-hidden="true"></i> </font><br><br>MANUAL <br>CARTA ALIR</font></b></div></center></a>
                </td>
                <td></td>
                <td></td>
                <td></td>

            </tr>
        </table>

        

</section>