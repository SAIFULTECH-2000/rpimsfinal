
<section class="form-section">
<br>
<div id="back-borang">
    <a href="<?=base_url('urusmaklumat')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a><br><br><br>
</div>
<form method="post" enctype="multipart/form-data" class="borang" action="<?=base_url('urusmaklumat/daftar_perlantikan_rp')?>">
        <h4><b><i class="fa fa-university " aria-hidden="true"></i>&nbsp;&nbsp;Daftar Perlantikan</b></h4>
        <hr>
        <?php
            if (isset($msg)) 
            {
                echo $msg;
            }
            
        ?>

        <table class="form-table">
            <tr>
                <td colspan="2">
                    <b>Kursus :</b>
                    <br>
                        <?php
                     
                            $NoPekerja=$this->session->userdata('username');
                            $result= $this->db->query("SELECT KodJab FROM staf where NoPekerja like '$NoPekerja'")->row_array();
                            $KodJab = $result['KodJab'];
                            $result = $this->db->query("SELECT KodKursus, NamaKursus,KodJab from kursus WHERE  kodJab like '$KodJab' ORDER BY KodKursus ASC")->result_array();
                            $kursus= $this->uri->segment('4');
                          
                            echo "<select style='width:450px;' name='KodKursus' value='KodKursus' required>";
                            echo '<option value="" disabled selected hidden>Sila Pilih</option>';
                            foreach ( $result as $row ) 
                            {
                                ?>
                                <option value="<?php echo $row['KodKursus']; ?> "<?php if($kursus==$row['KodKursus'])echo 'selected';?> ><?php echo $row['KodKursus'].' - '.$row['NamaKursus']; ?></option>
                                <?php
                            }
                            echo "</select>";
                        ?>
                        <br>
                    </div><br><br>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <b>Pensyarah :</b>
                    <br>
                    <?php
                      
                     $id= $this->uri->segment('3');
                        $result = $this->db->query("SELECT  NoPekerja, NamaStaf from staf WHERE status='active' and kodJab like '$KodJab' ORDER BY NamaStaf ASC")->result_array();
                        ?>
                        <select style="width:450px;" name='NoPekerja' value='NoPekerja' data-toggle='tooltip' data-placement='left' title='Sila daftarkan Pensyarah terlebih dahulu sekiranya tidak dipaparkan di dalam senarai Pensyarah.' required>
                            <option value="" disabled selected hidden>Sila Pilih</option>
                            <?php
                       
                            foreach ($result as $row ) 
                            {
                                ?>
                                <option value="<?php echo $row['NoPekerja']; ?> "<?php if($id==$row['NoPekerja']) echo 'selected';?>  ><?php echo $row['NamaStaf']; ?>&nbsp;<b>(<?php echo $row['NoPekerja']; ?>)<b></option>
                                <?php
                            }
                            ?>
                        </select>
                    <br><br>
                </td>
                <?php
            //   $role_id=  $this->session->userdata('role_id');
            //   if($role_id==1)
            //   //echo '  <td>
            //   <b>Pengesahan :</b>
            //   <br>
            //   <select name="disahkan" value="disahkan" required>
            //      <option value="" disabled selected hidden>&nbsp;--</option>
            //      <option value="Sah">Sah</option>
            //      <option value="Belum disahkan">Belum disahkan</option>
            //   </select>
            //   </td>';
                ?>
                <input type="hidden" name="disahkan" value="Belum disahkan"/>
                
              
                
            </tr>
            <tr>
                <td>
                    <b>Tarikh Mula :</b>
                    <br>
                    <input type="date" class="form-control" placeholder="Tarikh Mula" name="TarikhMula" required  />
                    <br><br>
                </td>
                <td>
                    <b>Tarikh Tamat :</b>
                    <br>
                    <input type="date" class="form-control" placeholder="" name="TarikhTamat" required  />
                    <br><br>
                </td>
                <td></td>
            </tr>
            <tr>
                <td colspan="3">
                    <button type="submit" class="button-ungu button4" name="btn-signup">Daftar Perlantikan</button>
                </td>
            </tr>
        </table>         
    </form>
</section>
