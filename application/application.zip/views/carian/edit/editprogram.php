<div id="back-borang">
    <a href="<?=base_url('carian/program')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a><br><br><br>
</div>
<section class="form-section">

    <form method="post" class="borang">
      
        <h4><b><i class="fa fa-graduation-cap" aria-hidden="true"></i>&nbsp;&nbsp;Daftar Program</b></h4>
        <hr>
        <?php
            if (isset($msg)) {
                echo $msg;
            }
        ?>
        <br/>

        <b>Kod Program :</b>
        <br/>
        <input type="text" placeholder="" name="KodProgram" value="<?=$row['KodProgram']?>"readonly />
        <br/><br/>
        

        <b>Nama Program :</b>
        <br/>
        <input type="text" placeholder="" name="NamaProgram"  value="<?=$row['NamaProgram']?>"  required  />
        <br/><br/>
        

        <b>Jabatan :</b>
        <br/>
        <?php
           

           $result = $this->db->query("SELECT KodJab, NamaJabBhg from JABATAN WHERE status='active' ORDER BY NamaJabBhg ASC")->result_array();
               
           echo "<select name='KodJab' value='KodJab' required>";
           echo '<option value="" disabled selected hidden>&nbsp&nbsp--</option>';
           foreach($result as $rows):
           
       ?>
       <option value="<?=$rows['KodJab']?>" <?php if($row['KodJab'] ==$rows['KodJab']){echo "selected";}?> ><?=$rows['NamaJabBhg']?>&nbsp;(<?=$rows['KodJab']?>)</option>
       <?php
       endforeach;
       ?>
       </select>
        <br/><br/>
        <button type="submit" class="button-ungu button4" name="btn-signup">&nbsp; Daftar Program</button>
    </form>
</section>