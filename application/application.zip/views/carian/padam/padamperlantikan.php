

 <div id="back">
    <a href="<?=base_url('carian/perlantikan')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a><br><br><br>
</div>

<script type='text/javascript'>
function confirmDelete()
{
   return confirm("Teruskan untuk hapus perlantikan?");
}
</script>

<body>

<section>

  <form method="post" action="">

                    <h2><i class="fa fa-building-o" aria-hidden="true"></i>&nbsp;&nbsp;Hapus Perlantikan</h2>
                    <hr>
                    
                    
                  
                    <?php
                      if (isset($msg)) {
                       echo $msg;
                      }
                      ?>

                    <br>
                      <table>
                      <tr>
                <td colspan="2">
                    <b>Kursus :<?=$row['KodKursus']?>(<?=$row['NamaKursus']?>)</b>
                    <br>
                        
                        <br>
                    </div><br><br>
                </td>
                <td>
                  
                </td>
            </tr>
            <tr>
                <td colspan="2">

                    <b>Pensyarah :<?=$row['NamaStaf']?></b>
                    <br>
                  <input type="hidden" name="NamaStaf" value="<?=$row['NamaStaf']?>" />
                  <input type="hidden" name="id" value="<?=$row['id']?>" />
                     
                    <br><br>
                </td>
              
            </tr>
            <tr>
                <td>
                    <b>Tarikh Mula :<?=$row['TarikhMula']?></b>
                    <br>
                    <!-- <input type="date" class="form-control" placeholder="Tarikh Mula" name="TarikhMula" required  /> -->
                    <br><br>
                </td>
                <td>
                    <b>Tarikh Tamat :<?=$row['TarikhTamat']?></b>
                    <br>
                    <!-- <input type="date" class="form-control" placeholder="" name="TarikhTamat" va required  /> -->
                    <br><br>
                </td>
                <td></td>
            </tr>
                      </table>

                    <span class="tooltiptext">Tekan <b>hapus</b> untuk hapuskan jabatan <br>atau <b>batal</b> untuk kembali.</span>
                    </div><br><br>

                    <button type="submit" class="button1 button4 button2" name = "submit" value = "Update" onclick="return confirmDelete()">Hapus</button> 



  </form>

  
</section>
