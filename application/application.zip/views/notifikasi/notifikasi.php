<div id="back-menu">
		<a href="<?=base_url('auth')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a><br><br><br>
</div>
<section>
		<table align="center" width="90%">
		
			<tr>
				<td colspan="5">
					<b><font size = "5"> <br> <i class="fa fa-file-text-o" aria-hidden="true"></i>&nbsp NOTIFIKASI</font></b>
					<hr>
				</td>
			</tr>
			<tr>
				<td width="20%"><a href="<?=base_url('notifikasi/rp_akan_tamat')?>"><div class="container"><br><br><b><center><font size = "5"> <i class="fa fa-battery-quarter fa-2x" aria-hidden="true"></i> </font><br><br>RP YANG<br/>AKAN TAMAT</font></b></div></center><a>
				</td>

				<td width="20%"><a href="<?=base_url('notifikasi/tamat')?>"><div class="container"><br><br> <b><font size = "5"> <i class="fa fa-battery-empty fa-2x" aria-hidden="true"></i> </font><br><br>RP YANG<br/>TELAH TAMAT</font></b></div></td><a>
                <td></td>
                <td></td>
                <td></td>
                </tr>
			
		</table>
</section>
