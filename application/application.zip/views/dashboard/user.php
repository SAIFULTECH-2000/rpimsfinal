<div id="back-menu">
		<a href="<?=base_url('auth')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a><br><br><br>
</div>
<br>
<section>
		<table align="center">
		
			<tr>
				<td colspan="5">
					<b><font size = "5"> <br> <i class="fa fa-diamond" aria-hidden="true"></i>&nbsp USER</font></b> 
					<hr>
			</tr>

			<tr>
                <td><a href="<?=base_url('user/profile')?>" class="menu-button"><div class="container"><br><br><b><font size = "5"> <i class="fa fa-address-card-o fa-2x" aria-hidden="true"></i> </font><br><br>User<br>Profile<br></font></b></div><a>
                </td>

                <td><a href="<?=base_url('user/kemaskini')?>" class="menu-button"><div class="container"><br><br><b><font size = "5"> <i class="fa fa-user-o fa-2x" aria-hidden="true"></i> </font><br><br>Kemaskini<br>Profile<br></font></b></div></td><a>
                <td><a href="<?=base_url('user/perlantikan')?>"><div class="container"><br><br> <b><font size = "5"> <i class="fa fa-file-text-o fa-2x" aria-hidden="true"></i> </font><br><br>Perlantikan RP</font></b></div></td><a>

            </tr>

			
		</table>

		

</section>
