<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Carian extends CI_Controller {
    public function index() {
        $this->load->view('components/header');
        $this->load->view('carian/pencarian');
        $this->load->view('components/footer');
    }
    public function jabatan()
    {
        $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("SELECT * FROM jabatan where status='active' ORDER BY KodJab ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/jabatan',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("SELECT * FROM jabatan where status='active'and (KodJab LIKE '$search' OR NamaJabBhg LIKE '$search')  ORDER BY KodJab ASC")->result_array();
        $data['search']=$search;
        $this->load->view('components/header');
        $this->load->view('carian/jabatan',$data);
        $this->load->view('components/footer');  

         }
        
    }
    public function kemaskini_jabatan()
    {
        $KodJab = $this->input->post('KodJab');
        if($KodJab==null){
            redirect('carian/jabatan');
        }else{
            $this->form_validation->set_rules('NamaJabBhg', 'NamaJabBhg', 'required|trim');
            if($this->form_validation->run()==false){
         $data['row']=$this->db->query("Select * from jabatan where KodJab like '$KodJab'")->row_array();
           $this->load->view('components/header');
           $this->load->view('carian/edit/editjabatan',$data);
           $this->load->view('components/footer'); 
            }else{
               $data = array(
                   'KodJab'=>$this->input->post('KodJab'),
                   'NamaJabBhg'=>$this->input->post('NamaJabBhg'),
                   
               );
               $this->db->set($data);
               $this->db->where('KodJab',$KodJab);
               $this->db->update('jabatan');
               redirect('carian/jabatan');
            }
        }
    }
    public function padam_jabatan()
    {
        $KodJab = $this->input->post('KodJab');
        if($KodJab==null){
            redirect('carian/jabatan');
        }else{
            $this->form_validation->set_rules('NamaJabBhg', 'NamaJabBhg', 'required|trim');
            if($this->form_validation->run()==false){
         $data['row']=$this->db->query("Select * from jabatan where KodJab like '$KodJab'")->row_array();
           $this->load->view('components/header');
           $this->load->view('carian/padam/padamjabatan',$data);
           $this->load->view('components/footer'); 
            }else{
            $this->db->set('status','tidak active');
            $this->db->where('KodJab',$KodJab);
            $this->db->update('jabatan');
            redirect('carian/jabatan');
            }
        }
    }
    public function kursus(){
         $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("SELECT * FROM kursus where status='active' ORDER BY KodKursus ASC")->result_array();
        $data['carian']= "kursus";
        $this->load->view('components/header');
        $this->load->view('carian/kursus',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("SELECT * FROM kursus where status='active' ORDER BY KodKursus ASC")->result_array();
        $data['search']=$search;
        $carian =$this->input->post('carian');
         if($carian == "kursus")
            $query = $this->db->query("SELECT * FROM kursus where status='active' and (KodKursus like '$search' or NamaKursus like '$search') ORDER BY KodKursus ASC")->result_array();
        else
            $query = $this->db->query("SELECT * FROM kursus where status='active' and KodJab like '$search' ORDER BY KodKursus ASC")->result_array();

        $data['result']=$query;
        $data['carian']=$carian;
        $this->load->view('components/header');
        $this->load->view('carian/kursus',$data);
        $this->load->view('components/footer');  

         }
    }
    public function kemaskini_kursus()
    {
        $KodKursus = $this->input->post('KodKursus');
        if($KodKursus==null){
            redirect('carian/kursus');
        }else{
            $data['row']=$this->db->query("Select * from kursus where KodKursus = '$KodKursus'")->row_array();
            $this->form_validation->set_rules('NamaKursus', 'NamaKursus', 'required|trim');
             if($this->form_validation->run()==false){
            $this->load->view('components/header');
            $this->load->view('carian/edit/editkursus',$data);
            $this->load->view('components/footer'); 
             }else{
                $data = array(
                    'KodJab'=>$this->input->post('KodJab'),
                    'KodKursus'=>$this->input->post('KodKursus'),
                    'NamaKursus'=>$this->input->post('NamaKursus'),
                );
                $this->db->set($data);
                $this->db->where('KodKursus',$KodKursus);
                $this->db->update('kursus');
                redirect('carian/kursus');
             }
        }
    }
    public function padam_kursus()
    {
        $KodKursus = $this->input->post('KodKursus');
        if($KodKursus==null){
            redirect('carian/kursus');
        }else{
            $data['row']=$this->db->query("Select * from kursus where KodKursus = '$KodKursus'")->row_array();
            $this->form_validation->set_rules('NamaKursus', 'NamaKursus', 'required|trim');
             if($this->form_validation->run()==false){
            $this->load->view('components/header');
            $this->load->view('carian/padam/padamkursus',$data);
            $this->load->view('components/footer'); 
             }else{
                $this->db->set('status','tidak active');
                $this->db->where('KodKursus',$KodKursus);
                $this->db->update('kursus');
                redirect('carian/kursus');
 
             }
        }
    }
    public function kampus()
    {
        $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("SELECT * FROM kampus WHERE status='active'  ORDER BY KodKampus ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/kampus',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("SELECT * FROM kampus WHERE status='active' and (KodKampus LIKE '$search' OR NamaKampus LIKE '$search')  ORDER BY KodKampus ASC")->result_array();
        $data['search']=$search;
        $this->load->view('components/header');
        $this->load->view('carian/kampus',$data);
        $this->load->view('components/footer');  

         }
    }
    public function kemaskini_kampus()
    {
        $KodKampus= $this->input->post('KodKampus');
        if($KodKampus===null){
            redirect('carian/kampus');
        }else{
            $data['row']=$this->db->query("SELECT * FROM kampus where KodKampus like '$KodKampus'")->row_array();
           $this->form_validation->set_rules('NamaKampus','NamaKampus','required|trim');
           if($this->form_validation->run()==false){
            $this->load->view('components/header');
            $this->load->view('carian/edit/editkampus',$data);
            $this->load->view('components/footer');  
           }else{
               $data = array(
                   'KodKampus'=>$this->input->post('KodKampus'),
                   'NamaKampus'=>$this->input->post('NamaKampus'),
               );
               $this->db->set($data);
               $this->db->where('KodKampus',$KodKampus);
               $this->db->update('kampus');
               redirect('carian/kampus');
           }
        }
    }
    public function padam_kampus()
    {
        $KodKampus= $this->input->post('KodKampus');
        if($KodKampus===null){
            redirect('carian/kampus');
        }else{
            $this->form_validation->set_rules('NamaKampus','NamaKampus','required|trim');
            $data['row']=$this->db->query("SELECT * FROM kampus where KodKampus like '$KodKampus'")->row_array();
           if($this->form_validation->run()==false){
            $this->load->view('components/header');
            $this->load->view('carian/padam/padamkampus',$data);
            $this->load->view('components/footer'); 
           }else{
               $this->db->set('status','tidak active');
               $this->db->where('KodKampus',$KodKampus);
               $this->db->update('kampus');
               redirect('carian/kampus');

           } 
        }
    }

    public function perlantikan()
    {
	$this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("SELECT perlantikan.print, perlantikan.disahkan, perlantikan.id,perlantikan.NoPekerja, perlantikan.KodKursus, kursus.NamaKursus, 
                                staf.NamaStaf, perlantikan.TarikhMula, perlantikan.TarikhTamat, perlantikan.SuratPerlantikan
								FROM perlantikan 
									INNER JOIN kursus ON perlantikan.KodKursus=kursus.KodKursus 
									INNER JOIN staf ON perlantikan.NoPekerja=staf.NoPekerja
                                WHERE perlantikan.status='active'
                                ORDER BY KodKursus ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/perlantikan',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("SELECT perlantikan.id,perlantikan.NoPekerja, perlantikan.KodKursus, kursus.NamaKursus, 
                                staf.NamaStaf, perlantikan.TarikhMula, perlantikan.TarikhTamat, perlantikan.SuratPerlantikan
								FROM perlantikan 
									INNER JOIN kursus ON perlantikan.KodKursus=kursus.KodKursus 
									INNER JOIN staf ON perlantikan.NoPekerja=staf.NoPekerja
                                WHERE perlantikan.status='active'
                                and (NamaStaf LIKE '%$search%' or perlantikan.KodKursus LIKE '%$search%')and (NamaStaf LIKE '%$search%' or perlantikan.KodKursus LIKE '%$search%')
                                ORDER BY KodKursus ASC")->result_array();
        $data['search']=$search;
        $this->load->view('components/header');
        $this->load->view('carian/perlantikan',$data);
        $this->load->view('components/footer');  

         }
    }
    public function kemaskini_perlantikan()
    {
        $id = $this->input->post('id');
        if($id==null){
            redirect('carian/perlantikan');
        }else{

            $data['row']=$this->db->query("SELECT * FROM perlantikan INNER JOIN kursus ON perlantikan.KodKursus=kursus.KodKursus 
            INNER JOIN staf ON  perlantikan.NoPekerja=staf.NoPekerja WHERE perlantikan.id='$id'")->row_array();
           	$this->form_validation->set_rules('NamaStaf', 'NamaStaf', 'required|trim');
            if($this->form_validation->run()==false){
            $this->load->view('components/header');
            $this->load->view('carian/edit/editperlantikan',$data);
            $this->load->view('components/footer');  
            }else{
                if($this->input->post('disahkan')!=null)
                $this->db->set('disahkan',$this->input->post('disahkan'));
                if($this->input->post('tarikhsurat')!=null)
                $this->db->set('tarikhsurat',$this->input->post('tarikhsurat'));
                $this->db->where('id',$id);
                $this->db->update('perlantikan');
                redirect('carian');
            }
        }
    }
    public function padam_perlantikan()
    {
        $id = $this->input->post('id');
        if($id==null){
            redirect('carian/perlantikan');
        }else{
            $data['row']=$this->db->query("SELECT * FROM perlantikan INNER JOIN kursus ON perlantikan.KodKursus=kursus.KodKursus 
            INNER JOIN staf ON perlantikan.NoPekerja=staf.NoPekerja WHERE perlantikan.id='$id'")->row_array();
           	$this->form_validation->set_rules('NamaStaf', 'NamaStaf', 'required|trim');
            if($this->form_validation->run()==false){
            $this->load->view('components/header');
            $this->load->view('carian/padam/padamperlantikan',$data);
            $this->load->view('components/footer');  
            }else{
                $this->db->set('status','tidak active');
                $this->db->where('id',$id);
                $this->db->update('perlantikan');
                redirect('carian/perlantikan');
            }
        }
    }
    public function cawangan()
	{
		$this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("SELECT cawangan.KodJab, jabatan.NamaJabBhg, kampus.NamaKampus 
        FROM cawangan 
            INNER JOIN jabatan ON cawangan.KodJab=jabatan.KodJab 
            INNER JOIN kampus ON cawangan.KodKampus=kampus.KodKampus 

        WHERE cawangan.status='active'
                            
								ORDER BY KodJab ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/cawangan',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("SELECT cawangan.KodJab, jabatan.NamaJabBhg, kampus.NamaKampus 
								FROM cawangan 
									INNER JOIN jabatan ON cawangan.KodJab=jabatan.KodJab 
									INNER JOIN kampus ON cawangan.KodKampus=kampus.KodKampus 

								WHERE cawangan.status='active'
                                AND (cawangan.KodJab LIKE '%$search%' OR cawangan.KodKampus LIKE '$search' OR NamaKampus LIKE '$search' OR NamaJabBhg LIKE '$search')
								ORDER BY KodJab ASC")->result_array();
        $data['search']=$search;
        $this->load->view('components/header');
        $this->load->view('carian/cawangan',$data);
        $this->load->view('components/footer');  

         }
	}
    public function program()
    {
    
        $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("SELECT * FROM program WHERE status='active' ORDER BY KodProgram ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/program',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("SELECT * FROM program WHERE status='active'  AND (KodProgram LIKE '$search' OR NamaProgram LIKE '$search' OR KodJab LIKE '$search') ORDER BY KodProgram ASC")->result_array();
        $data['search']=$search;
        $this->load->view('components/header');
        $this->load->view('carian/program',$data);
        $this->load->view('components/footer');  

         
        }        

        
    }
    public function kemaskini_program()
    {
        $KodProgram= $this->input->post('KodProgram');
        if($KodProgram==null){
            redirect('carian/program');
        }else{
            $data['row']=$this->db->query("SELECT * FROM program where KodProgram like '$KodProgram'")->row_array();
           $this->form_validation->set_rules('NamaProgram','NamaProgram','required|trim');
           if($this->form_validation->run()==false){
            $this->load->view('components/header');
            $this->load->view('carian/edit/editprogram',$data);
            $this->load->view('components/footer');  
           }else{
               $data = array(
                   'KodProgram'=>$this->input->post('KodProgram'),
                   'NamaProgram'=>$this->input->post('NamaProgram'),
                   'KodJab'=>$this->input->post('KodJab'),
               );
               $this->db->set($data);
               $this->db->where('KodProgram',$KodProgram);
               $this->db->update('program');
               redirect('carian/program');
           }
        }
    }
    public function padam_program()
    {
        $KodProgram= $this->input->post('KodProgram');
        if($KodProgram==null){
            redirect('carian/program');
        }else{
            $data['query2']=$this->db->query("SELECT * FROM program where KodProgram like '$KodProgram'")->row_array();
           $this->form_validation->set_rules('NamaProgram','NamaProgram','required|trim');
        
           if($this->form_validation->run()==false){
            $this->load->view('components/header');
            $this->load->view('carian/padam/padamprogram',$data);
            $this->load->view('components/footer'); 
           }else{
               $this->db->set('status','tidak active');
               $this->db->where('KodProgram',$KodProgram);
               $this->db->update('program');
               redirect('carian/program');

           } 
        }
    }
    
    public function pengajaran()
    {
        $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("SELECT pengajaran.NoPekerja, pengajaran.KodKursus, kursus.NamaKursus, staf.NamaStaf, pengajaran.KodSem
								FROM pengajaran 
									INNER JOIN kursus ON pengajaran.KodKursus=kursus.KodKursus 
									INNER JOIN staf ON pengajaran.NoPekerja=staf.NoPekerja 

								WHERE pengajaran.status='active'
                                ORDER BY KodSem DESC, KodKursus ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/penganjaran',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("SELECT pengajaran.NoPekerja, pengajaran.KodKursus, kursus.NamaKursus, staf.NamaStaf, pengajaran.KodSem
								FROM pengajaran 
									INNER JOIN kursus ON pengajaran.KodKursus=kursus.KodKursus 
									INNER JOIN staf ON pengajaran.NoPekerja=staf.NoPekerja 

								WHERE pengajaran.status='active'
                                and pengajaran.KodKursus = '$search'
                                ORDER BY KodSem DESC, KodKursus ASC")->result_array();
        $data['search']=$search;
        $this->load->view('components/header');
        $this->load->view('carian/penganjaran',$data);
        $this->load->view('components/footer');  

         }
    }
    public function staf()
    {   
        $this->form_validation->set_rules('carian', 'carian', 'required|trim');
        $this->form_validation->set_rules('search', 'search', 'required|trim');
       
        if($this->form_validation->run()==false){
         $data['result']=$this->db->query("SELECT * FROM staf  where status like 'active' ORDER BY NoPekerja ASC")->result_array();
        $data['carian']= 'AKTIF';
        $data['status']='AKTIF';
        $this->load->view('components/header');
        $this->load->view('carian/staf',$data);
        $this->load->view('components/footer');
        }else{
        $search = $this->input->post('search');
        $status = $this->input->post('carian');
        $data['result']=$this->db->query("SELECT * FROM staf where  (NoPekerja LIKE '$search' OR NamaStaf LIKE '$search') AND status = '$status'  ORDER BY NoPekerja ASC")->result_array();
        
       
        $data['carian']=$status;
        $data['status']=$status;
        $data['search']= $search;
        $data['hasil'] = true;
        $this->load->view('components/header');
        $this->load->view('carian/staf',$data);
        $this->load->view('components/footer');
        }
    }
    public function profile_staf(){
       $NoPekerja= $this->input->post('NoPekerja');
       if(empty($NoPekerja)){
        redirect('Carian/staf');
       }else{
        $data['query2'] =$this->db->query("SELECT * FROM staf where NoPekerja = '$NoPekerja'")->row_array();
        $this->load->view('components/header');
        $this->load->view('carian/profilestaf',$data);
        $this->load->view('components/footer');
       }
    }
    public function kemaskini_staf()
    {
        $NoPekerja= $this->input->post('NoPekerja');
       if(empty($NoPekerja)){
        redirect('Carian/staf');
       }else{
        $this->form_validation->set_rules('NoICStaf', 'NoICStaf', 'required|trim');
        if($this->form_validation->run()==false){
        $data['query2'] =$this->db->query("SELECT * FROM staf where NoPekerja = '$NoPekerja' ")->row_array();
        $data['query3'] =$this->db->query("SELECT * FROM users WHERE NoPekerja = '$NoPekerja'")->row_array();
        $this->load->view('components/header');
        $this->load->view('carian/edit/editstaf',$data);
        $this->load->view('components/footer');
        }else{
            $data2 = array(
                "NoPekerja"=>$this->input->post("NoPekerja"),
                "NoICStaf"=>$this->input->post("NoICStaf"),
                "NamaStaf"=>$this->input->post("NamaStaf"),
                "KodJab"=>$this->input->post("KodJab"),
                "KodKampus"=>$this->input->post("KodKampus"),
                "Jantina"=>$this->input->post("Jantina"),
                "Emel"=>$this->input->post("Emel"),
                "TelBilik"=>$this->input->post("TelBilik"),
                "TelMobil"=>$this->input->post("TelMobil"),
                "GredJawatan"=>$this->input->post("GredJawatan"),
                "TarikhMulaKhidmat"=>$this->input->post("TarikhMulaKhidmat"),
                "TarikhPencen"=>$this->input->post("TarikhPencen"),
                "JenisLantikan"=>$this->input->post("JenisLantikan"),
            );
            $data1 =array(
                "role_id"=>$this->input->post("role"),
                "username"=>$this->input->post("NoPekerja"),
                "NoPekerja"=>$this->input->post("NoPekerja"),
                "email"=>$this->input->post("Emel"),
         
            );
            $this->db->set($data2);
            $this->db->where("NoPekerja",$this->input->post("NoPekerja"));
            $this->db->update('staf');
            $this->db->set($data1);
            $this->db->where("NoPekerja",$this->input->post("NoPekerja"));
            $this->db->update('users');
            redirect('carian/staf');
        }
       }
    }
    public function padam_staf() {
        $NoPekerja= $this->input->post('NoPekerja');
        if($NoPekerja==null){
         redirect('Carian/staf');
        }else{
            $this->form_validation->set_rules('NoICStaf', 'NoICStaf', 'required|trim');
     if($this->form_validation->run()==false){
         $data['query2'] =$this->db->query("SELECT * FROM staf where NoPekerja = '$NoPekerja'")->row_array();
         $data['query3'] =$this->db->query("SELECT * FROM users WHERE NoPekerja = '$NoPekerja'")->row_array();
         $this->load->view('components/header');
         $this->load->view('carian/padam/padamstaf',$data);
         $this->load->view('components/footer');
         }else{
          
            //  $data1 =array(
            //      'status'=>'tidak active',
            //  );
             $this->db->set('status','tidak active');
             $this->db->where("NoPekerja",$this->input->post("NoPekerja"));
             $this->db->update('staf');
          
          
             redirect('carian/staf');
         }
        }
    }
    public function subjek()
    {
        $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("
        SELECT subjek.KodProgram, program.NamaProgram, subjek.KodKursus, kursus.NamaKursus, subjek.BhgPelan
								 FROM subjek 
									INNER JOIN program ON subjek.KodProgram=program.KodProgram 
									INNER JOIN kursus ON subjek.KodKursus=kursus.KodKursus 

									WHERE subjek.status='active'

									ORDER BY subjek.BhgPelan, subjek.KodProgram ASC
                                    ")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/subjek',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("
        SELECT subjek.KodProgram, program.NamaProgram, subjek.KodKursus, kursus.NamaKursus, subjek.BhgPelan
								 FROM subjek 
									INNER JOIN program ON subjek.KodProgram=program.KodProgram 
									INNER JOIN kursus ON subjek.KodKursus=kursus.KodKursus 

									WHERE subjek.status='active'
                                    AND (subjek.KodProgram LIKE '%$search%' OR subjek.KodKursus LIKE '%$search%' OR NamaProgram LIKE '%$search%' OR subjek.BhgPelan LIKE '%$search%' OR NamaKursus LIKE '%$search%') 
									ORDER BY subjek.BhgPelan, subjek.KodProgram ASC")->result_array();
        $data['search']=$search;
        $this->load->view('components/header');
        $this->load->view('carian/subjek',$data);
        $this->load->view('components/footer');  

         }
    }
    public function semester()
    {
         $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("SELECT * FROM semester WHERE status='active' ORDER BY KodSem ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/semester',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("SELECT * FROM semester WHERE status='active'  and (KodSem LIKE '%$search%' OR NamaSem LIKE '%$search%') ORDER BY KodSem ASC")->result_array();
        $data['search']=$search;
        $this->load->view('components/header');
        $this->load->view('carian/semester',$data);
        $this->load->view('components/footer');  

         }
        
    }
    public function kemaskini_semester()
    {
        $KodSem = $this->input->post('KodSem');
        if($KodSem==null){
            redirect('carian/semester');
        }else{
            $this->form_validation->set_rules('NamaSem', 'NamaSem', 'required|trim');
            if($this->form_validation->run()==false){

         $data['row']=$this->db->query("Select * from semester where KodSem like '$KodSem'")->row_array();
           $this->load->view('components/header');
           $this->load->view('carian/edit/editsemester',$data);
           $this->load->view('components/footer'); 
            }else{
               $data = array(
                   'KodSem'=>$this->input->post('KodSem'),
                   'NamaSem'=>$this->input->post('NamaSem'),
                   
               );
               $this->db->set($data);
               $this->db->where('KodSem',$KodSem);
               $this->db->update('semester');
               redirect('carian/semester');
            }
        }
    }
    public function padam_semester()
    {
        $KodSem = $this->input->post('KodSem');
        if($KodSem==null){
            redirect('carian/semester');
        }else{
            $this->form_validation->set_rules('NamaSem', 'NamaSem', 'required|trim');
            if($this->form_validation->run()==false){
            $data['query2']=$this->db->query("Select * from semester where KodSem like '$KodSem'")->row_array();
           $this->load->view('components/header');
           $this->load->view('carian/padam/padamsemester',$data);
           $this->load->view('components/footer'); 
            }else{
            $this->db->set('status','tidak active');
            $this->db->where('KodSem',$KodSem);
            $this->db->update('semester');
            redirect('carian/semester');
            }
        }
    }
    public function perlantikan_yg_perlu_pengesahan(){
        $data['result'] = $this->db->query("SELECT perlantikan.print, perlantikan.disahkan, perlantikan.id,perlantikan.NoPekerja, perlantikan.KodKursus, kursus.NamaKursus, 
        staf.NamaStaf, perlantikan.TarikhMula, perlantikan.TarikhTamat, perlantikan.SuratPerlantikan
        FROM perlantikan 
            INNER JOIN kursus ON perlantikan.KodKursus=kursus.KodKursus 
            INNER JOIN staf ON perlantikan.NoPekerja=staf.NoPekerja
        WHERE perlantikan.status='active' and perlantikan.disahkan != 'Sah'
        ORDER BY KodKursus ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/perlantikanrpygperlupengesahan',$data);
        $this->load->view('components/footer');
    }
    public function  perlantikan_yang_perlu_dicetak()
    {
        $data['result'] = $this->db->query("SELECT perlantikan.dicetakoleh,perlantikan.tarikhsurat,perlantikan.print, perlantikan.disahkan, perlantikan.id,perlantikan.NoPekerja, perlantikan.KodKursus, kursus.NamaKursus, 
        staf.NamaStaf, perlantikan.TarikhMula, perlantikan.TarikhTamat, perlantikan.SuratPerlantikan
        FROM perlantikan 
            INNER JOIN kursus ON perlantikan.KodKursus=kursus.KodKursus 
            INNER JOIN staf ON perlantikan.NoPekerja=staf.NoPekerja
        WHERE perlantikan.status='active' and perlantikan.disahkan like 'Sah'
        ORDER BY KodKursus ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('carian/perlantikan_yang_perlu_dicetak',$data);
        $this->load->view('components/footer');
    }
}