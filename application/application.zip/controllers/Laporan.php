<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {
    public function index() {
        $this->load->view('components/header');
        $this->load->view('laporan/laporan');
        $this->load->view('components/footer');
    }
    public function staf_tidak_aktif()
    {
        $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result']=$this->db->query("SELECT * FROM staf WHERE status='inactive' ORDER BY NoPekerja ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('laporan/sta',$data);
        $this->load->view('components/footer');
        }else{
            $search = $this->input->post('search');
            $data['search']=$search;
            $data['result']= $this->db->query("SELECT * FROM staf WHERE status='inactive' AND (NoPekerja LIKE '$search%' OR NamaStaf LIKE '$search%') ORDER BY NamaStaf ASC")->result_array();
            $this->load->view('components/header');
        $this->load->view('laporan/sta',$data);
        $this->load->view('components/footer');
        }
    }
    public function rp_tidak_aktif()
    {
        $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result']=$this->db->query("SELECT perlantikantamat.NoPekerja, perlantikantamat.KodKursus, kursus.NamaKursus, staf.NamaStaf, perlantikantamat.TarikhMula, perlantikantamat.TarikhTamat, perlantikantamat.SuratPerlantikan
        FROM perlantikantamat
            INNER JOIN kursus ON perlantikantamat.KodKursus=kursus.KodKursus 
            INNER JOIN staf ON perlantikantamat.NoPekerja=staf.NoPekerja 
									WHERE perlantikantamat.status='inactive'
									ORDER BY perlantikantamat.TarikhTamat, perlantikantamat.KodKursus ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('laporan/rta',$data);
        $this->load->view('components/footer');
        }else{
        $search =$this->input->post('search');
        $data['search']=$search;
        $data['result']=$this->db->query("SELECT perlantikantamat.NoPekerja, perlantikantamat.KodKursus, kursus.NamaKursus, staf.NamaStaf, perlantikantamat.TarikhMula, perlantikantamat.TarikhTamat, perlantikantamat.SuratPerlantikan
											FROM perlantikantamat
												INNER JOIN kursus ON perlantikantamat.KodKursus=Kursus.KodKursus 
												INNER JOIN staf ON perlantikantamat.NoPekerja=staf.NoPekerja 

												WHERE perlantikantamat.status='inactive' AND (perlantikantamat.KodKursus LIKE '%$search%' OR perlantikantamat.NoPekerja LIKE '%$search%' OR NamaKursus LIKE '%$search%' OR NamaStaf LIKE '%$search%')

												ORDER BY KodKursus ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('laporan/rta',$data);
        $this->load->view('components/footer'); 
        }
    }
    public function system()
    {
        $this->load->view('components/header');
        $this->load->view('laporan/system');
        $this->load->view('components/footer');
    }
    public function kursus_tanpa_lantikan()
    {
         $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("Select * from perlantikantamat 
        left join staf on staf.NoPekerja = perlantikantamat.NoPekerja
        where KodKursus not in (select KodKursus from perlantikan)
                                    ")->result_array();
        $this->load->view('components/header');
        $this->load->view('laporan/ktl',$data);
        $this->load->view('components/footer');
        }else{
        $data['search'] = $this->input->post('search');
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("Select * from perlantikantamat 
                                    left join staf on staf.NoPekerja = perlantikantamat.NoPekerja
                                    where KodKursus not in (select KodKursus from perlantikan)
                                    and KodKursus like '%".$search."%'
                                    ")->result_array();
        $this->load->view('components/header');
        $this->load->view('laporan/ktl',$data);
        $this->load->view('components/footer');
        }
    }
    public function semester()
    {
        $this->form_validation->set_rules('search', 'search', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = $this->db->query("SELECT * FROM semester WHERE status='active' ORDER BY KodSem ASC")->result_array();
        $this->load->view('components/header');
        $this->load->view('laporan/semester',$data);
        $this->load->view('components/footer');   
         }else{
        $search = $this->input->post('search');
        $data['result'] = $this->db->query("SELECT * FROM semester WHERE status='active'  and (KodSem LIKE '%$search%' OR NamaSem LIKE '%$search%') ORDER BY KodSem ASC")->result_array();
        $data['search']=$search;
        $this->load->view('components/header');
        $this->load->view('laporan/semester',$data);
        $this->load->view('components/footer');  

         }
    }
    public function rp_dibawah_pusat_pengajian()
    {
        $NoPekerja=$this->session->userdata('username');
        $result= $this->db->query("SELECT KodJab FROM staf where NoPekerja like '$NoPekerja'")->row_array();
        $KodJab = $result['KodJab'];
        $data['result'] = $this->db->query("SELECT * FROM `perlantikan` inner join staf on perlantikan.NoPekerja = staf.NoPekerja inner join kursus on perlantikan.KodKursus = kursus.KodKursus inner join kampus on staf.KodKampus = kampus.KodKampus inner join jabatan on staf.KodJab = jabatan.KodJab WHERE  disahkan='Sah' and perlantikan.KodKursus in (SELECT KodKursus FROM `kursus` WHERE KodJab like '$KodJab') ")->result_array();

        $this->load->view('components/header');
        $this->load->view('laporan/rpdpp',$data);
        $this->load->view('components/footer');  

    }
    public function rp_dibawah_pusat_pengajian_admin()
    {   
       
        $this->form_validation->set_rules('KodJab', 'KodJab', 'required|trim');
        if($this->form_validation->run()==false){
        $data['result'] = "";
        $this->load->view('components/header');
        $this->load->view('laporan/rpdppa',$data);
        $this->load->view('components/footer');  
        }else{
            $KodJab = $_POST['KodJab'];
            $data['result'] = $this->db->query("SELECT * FROM `perlantikan` inner join staf on perlantikan.NoPekerja = staf.NoPekerja inner join kursus on perlantikan.KodKursus = kursus.KodKursus inner join kampus on staf.KodKampus = kampus.KodKampus inner join jabatan on staf.KodJab = jabatan.KodJab WHERE disahkan='Sah' and  perlantikan.KodKursus in (SELECT KodKursus FROM `kursus` WHERE KodJab like '$KodJab') ")->result_array();
            $this->load->view('components/header');
            $this->load->view('laporan/rpdppa',$data);
            $this->load->view('components/footer');  
        }

    }
    public function kursus_perlantikan()
    {
        $data['result'] = $this->db->query("SELECT perlantikan.print, perlantikan.disahkan, perlantikan.id,perlantikan.NoPekerja, perlantikan.KodKursus, kursus.NamaKursus, 
        staf.NamaStaf, perlantikan.TarikhMula, perlantikan.TarikhTamat, perlantikan.SuratPerlantikan
        FROM perlantikan 
            INNER JOIN kursus ON perlantikan.KodKursus=kursus.KodKursus 
            INNER JOIN staf ON perlantikan.NoPekerja=staf.NoPekerja
        WHERE perlantikan.status='active' and disahkan like'Sah'
        ORDER BY KodKursus ASC")->result_array();
           
        $this->load->view('components/header');
        $this->load->view('laporan/perlantikan',$data);
        $this->load->view('components/footer');   
    }
}