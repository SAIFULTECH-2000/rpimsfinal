<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function index()
	{  
        $role = $this->session->userdata('role_id');
        $data['role'] = $role;
        $data['result'] = $this->db->query("SELECT * FROM `accesscontrol` INNER JOIN menu on accesscontrol.menu_id =menu.id WHERE role_id =$role and accesscontrol.isactive=1")->result_array();
       //var_dump($role);die();
        $this->load->view('components/header');
         $this->load->view('dashboard/home',$data);
         $this->load->view('components/footer');
    }

}