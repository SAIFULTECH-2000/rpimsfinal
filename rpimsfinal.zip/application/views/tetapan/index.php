<div id="back-menu">
		<a href="<?=base_url('auth')?>"><button class="button" style="vertical-align:middle"><span><b>KEMBALI</b></span></button></a><br><br><br>
</div>
<section>
		<table align="center">
		
			<tr>
				<td colspan="5">
					<b><font size = "5"> <br> <i class="fa fa-diamond" aria-hidden="true"></i>&nbsp Tetapan</font></b> 
					<hr>
			</tr>

			<tr>
                <td><a href="<?=base_url('tetapan/mail')?>" class="menu-button"><div class="container"><br><br><b><font size = "5"> <i class="fa fa-envelope-open fa-2x" aria-hidden="true"></i> </font><br><br>MAIL<br> CONFIG</font></b></div><a>
                </td>

                <td><a href="<?=base_url('tetapan/accesscontrol')?>" class="menu-button"><div class="container"><br><br><b><font size = "5"> <i class="fa fa-user-o fa-2x" aria-hidden="true"></i> </font><br><br>ACCESS<br> CONTROL<br></font></b></div></td><a>

            

                <td><a href="<?=base_url('tetapan/suratperlantikan')?>" class="menu-button"><div class="container"><br><br> <b><font size = "5"> <i class="fa fa-file-text-o fa-2x" aria-hidden="true"></i> </font><br><br>SURAT<br>PERLANTIKAN</font></b></div></td><a>

            </tr>

			
		</table>

		

</section>