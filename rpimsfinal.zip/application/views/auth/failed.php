<!DOCTYPE html>

<html>
    <head>
        <title>Daftar Masuk</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
        <link rel="stylesheet" type="text/css" href="<?=base_url('assets/')?>css/failedstyle.css"> </link>
        <link rel="stylesheet" type="text/css" href="<?=base_url('assets/')?>css/font-awesome.min.css"></link>
        <link rel="stylesheet" href="<?=base_url('assets/')?>css/fonts.css">
    </head>

    <body>
        <div class="container">

        <p align="center">
        	<br><br><br><i class="fa fa-user-times fa-4x" aria-hidden="true"></i>
        	<br><br>Maaf, <b>nama pengguna</b> atau <b>kata laluan</b> <br>yang anda masukkan adalah salah.
        	<br><br>Sila <u>daftar masuk</u> semula :
        	<br><br><a href="<?=base_url('auth')?>"><button class="button button4">LOGIN</button></a>
        	</p>

        </div>
    </body>
</html>